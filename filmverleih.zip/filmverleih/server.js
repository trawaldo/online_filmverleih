// Datenbanken initialisieren
const sqlite3 = require('sqlite3').verbose();
let db_users = new sqlite3.Database('users.db',(error) => {
	if (error) {
		console.error(error.message);
	} else {
		console.log('Connected to the database users.db');
	}
});

let db_movies = new sqlite3.Database('movies.db',(error) => {
	if (error) {
		console.error(error.message);
	} else {
		console.log('Connected to the database movies.db');
	}
});

let db_status = new sqlite3.Database('status.db',(error) => {
	if (error) {
		console.error(error.message);
	} else {
		console.log('Connected to the database status.db');
	}
});

// Express.js Webserver
const express = require('express');
const app = express()

// Body-Parser: wertet POST-Formulare aus
const bodyParser= require('body-parser')
app.use(bodyParser.urlencoded({extended: true}))

// EJS Template Engine
app.engine('.ejs', require('ejs').__express);
app.set('view engine', 'ejs');

// Static Ordner einbinden
// Style.class, Javascript laden
app.use(express.static(__dirname + '/styles'));
app.use(express.static(__dirname + '/images'));
app.use(express.static(__dirname + '/bootstrap/dist/css'));
// app.use(express.static(__dirname + "/js"));

// Sessions
const session = require('express-session');
app.use(session({
    secret: 'soSecret',
    resave: false,
    saveUninitialized: true
}));

// Passwort Verschlüsselung
const passwordHash = require('bcrypt');

// Webserver starten http://localhost:9000
app.listen(9000, function(){
	console.log("listening on 9000");
});

// ----------- SEITEN -----------

app.get(['/','/welcome'], (req, res) => {
    if (!req.session.authenticated) {
        res.render('welcome');
    } else {
        res.redirect('allMovies');
    }
});

app.get('/registration', (req,res) => {
	res.render('registration', {
		'fehler': 0
	});
});

app.get('/success', (req,res) => {
  res.render('success');
});

app.get('/danke', (req,res) => {
  res.render('danke', {
		'name': req.session.user.name
	});
});

app.get('/profile', (req,res) => {
	console.log('/Profile:');
	const sessionName = req.session.user.name;
	db_status.run(`ATTACH 'movies.db' AS moviesdb;`, function(err) {
		if (err) {
			console.log(err.message);
		} else {
			const sql_rent = `SELECT filmTitle,filmName,imagePath FROM main.status s INNER JOIN moviesdb.movies m ON s.filmTitle = m.column_f WHERE s.uid = "${sessionName}";`;
			db_status.all(sql_rent, function(err, rows) {
				if (err) {
					console.log(err.message);
				} else {
					res.render('profile',{
						'rows': rows || [],
						'name': req.session.user.name
					});
				}
				db_status.run(`DETACH 'moviesdb';`, function(err) {
					if (err) console.log(err);
				});
			});
		}
	});
});

// ----------------------- FILM SEITEN -------------------------

// Findet Nemo
app.post('/findet_nemo', (req,res) => {
	const page = req.body["findet_nemo"];
	const sql = ` SELECT * FROM status WHERE mid = 'findet_nemo';`;
	let buttonActiveClass = "btn-danger";
	let buttonActive = "disabled";
	let buttonActiveText = "Nicht verfügbar";

	console.log(sql);

	db_status.all(sql, function(err, rows) {
		console.log(rows);
		if (rows == 0) {
			buttonActive = "enabled";
			buttonActiveClass = "btn-success";
			buttonActiveText ="Ausleihen"
		}
		if (err) {
			console.log(err.message);
		} else {
			res.render('findet_nemo',{
				'name': req.session.user.name,
				'buttonActive': buttonActive,
				'buttonActiveClass': buttonActiveClass,
				'buttonActiveText': buttonActiveText,
				'page': page
			});
		}
	});
});

// Herr der Ringe 3
app.post('/herr_der_ringe_3', (req,res) => {
	const page = req.body["herr_der_ringe_3"];
	const sql = `SELECT * FROM status WHERE mid ='herr_der_ringe_3';`;
	let buttonActiveClass = "btn-danger";
	let buttonActive = "disabled";
	let buttonActiveText = "Nicht verfügbar";

	console.log(sql);

	db_status.all(sql, function(err, rows) {
		console.log(rows);
		if (rows == 0) {
			buttonActive = "enabled";
			buttonActiveClass = "btn-success";
			buttonActiveText ="Ausleihen"
		}
		if (err) {
			console.log(err.message);
		} else {
			res.render('herr_der_ringe_3',{
				'name': req.session.user.name,
				'buttonActive': buttonActive,
				'buttonActiveClass': buttonActiveClass,
				'buttonActiveText': buttonActiveText,
				'page': page
			});
		}
	});
});

// Matrix
app.post('/matrix', (req,res) => {
	const page = req.body["matrix"];
	const sql = `SELECT * FROM status WHERE mid = 'matrix';`;
	let buttonActiveClass = "btn-danger";
	let buttonActive = "disabled";
	let buttonActiveText = "Nicht verfügbar";

	console.log(sql);

	db_status.all(sql, function(err, rows) {
		console.log(rows);
		if (rows == 0) {
			buttonActive = "enabled";
			buttonActiveClass = "btn-success";
			buttonActiveText ="Ausleihen"
		}
		if (err) {
			console.log(err.message);
		} else {
			res.render('matrix',{
				'name': req.session.user.name,
				'buttonActive': buttonActive,
				'buttonActiveClass': buttonActiveClass,
				'buttonActiveText': buttonActiveText,
				'page': page
			});
		}
	});
});

// Schuh des Manitu
app.post('/schuh_des_manitu', (req,res) => {
	const page = req.body["schuh_des_manitu"];
	const sql = `SELECT * FROM status WHERE mid = 'schuh_des_manitu';`;
	let buttonActiveClass = "btn-danger";
	let buttonActive = "disabled";
	let buttonActiveText = "Nicht verfügbar";

	console.log(sql);

	db_status.all(sql, function(err, rows) {
		console.log(rows);
		if (rows == 0) {
			buttonActive = "enabled";
			buttonActiveClass = "btn-success";
			buttonActiveText ="Ausleihen"
		}
		if (err) {
			console.log(err.message);
		} else {
			res.render('schuh_des_manitu',{
				'name': req.session.user.name,
				'buttonActive': buttonActive,
				'buttonActiveClass': buttonActiveClass,
				'buttonActiveText': buttonActiveText,
				'page': page
			});
		}
	});
});

// Shutter Island
app.post('/shutter_island', (req,res) => {
	const page = req.body["shutter_island"];
	const sql = `SELECT * FROM status WHERE mid = 'shutter_island';`;
	let buttonActiveClass = "btn-danger";
	let buttonActive = "disabled";
	let buttonActiveText = "Nicht verfügbar";

	console.log(sql);

	db_status.all(sql, function(err, rows) {
		console.log(rows);
		if (rows == 0) {
			buttonActive = "enabled";
			buttonActiveClass = "btn-success";
			buttonActiveText ="Ausleihen"
		}
		if (err) {
			console.log(err.message);
		} else {
			res.render('shutter_island',{
				'name': req.session.user.name,
				'buttonActive': buttonActive,
				'buttonActiveClass': buttonActiveClass,
				'buttonActiveText': buttonActiveText,
				'page': page
			});
		}
	});
});

// Twilight
app.post('/twilight', (req,res) => {
	const page = req.body["twilight"];
	const sql = `SELECT * FROM status WHERE mid = 'twilight';`;
	let buttonActiveClass = "btn-danger";
	let buttonActive = "disabled";
	let buttonActiveText = "Nicht verfügbar";

	console.log(sql);

	db_status.all(sql, function(err, rows) {
		console.log(rows);
		if (rows == 0) {
			buttonActive = "enabled";
			buttonActiveClass = "btn-success";
			buttonActiveText ="Ausleihen"
		}
		if (err) {
			console.log(err.message);
		} else {
			res.render('twilight',{
				'name': req.session.user.name,
				'buttonActive': buttonActive,
				'buttonActiveClass': buttonActiveClass,
				'buttonActiveText': buttonActiveText,
				'page': page
			});
		}
	});
});

// The Wolf of Wall Street
app.post('/wolf_of_wall_street', (req,res) => {
	const page = req.body["wolf_of_wall_street"];
	const sql = `SELECT * FROM status WHERE mid = 'wolf_of_wall_street';`;
	let buttonActiveClass = "btn-danger";
	let buttonActive = "disabled";
	let buttonActiveText = "Nicht verfügbar";

	console.log(sql);

	db_status.all(sql, function(err, rows) {
		console.log(rows);
		if (rows == 0) {
			buttonActive = "enabled";
			buttonActiveClass = "btn-success";
			buttonActiveText ="Ausleihen"
		}
		if (err) {
			console.log(err.message);
		} else {
			res.render('wolf_of_wall_street',{
				'name': req.session.user.name,
				'buttonActive': buttonActive,
				'buttonActiveClass': buttonActiveClass,
				'buttonActiveText': buttonActiveText,
				'page': page
			});
		}
	});
});


// ---------------- Formulare ----------------

// Login
app.post('/welcome', (req, res) => {
    let currentUser = {'name': req.body.name};
    req.session.name = req.body.name;
    res.redirect('/allMovies');
});

// Logout
app.post('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/welcome');
});

// Registrierung
app.post('/registrierung', (req,res) => {
	const name = req.body["name"];
  const email = req.body["email"];
	const password = req.body["password"];
	const password2 = req.body["password2"];
	db_users.get(`SELECT * FROM users WHERE email='${email}'`,(err,rows) => {
		db_users.get(`SELECT * FROM users WHERE name='${name}'`,(err,row) => {
			if (password == password2 && row == undefined && rows == undefined) {
				db_users.run(`INSERT INTO users (name, email, password) VALUES ('${name}','${email}','${password}')`,(error) => {
					if (error) {
						console.error(error.message);
					}
				});
				res.redirect('/welcome');
			} else if (password != password2) {
				res.render('registration', {'fehler': 1});
			} else if (row != undefined) {
				res.render('registration', {'fehler': 2});
			} else if (rows != undefined) {
				res.render('registration', {'fehler': 3});
			}
		});
	});
});


// Film zurückgeben
app.post('/givebackForm', (req,res) => {
	console.log('/givebackForm:');
	const movie = req.body["movie"];
	console.log(movie);
	const sql_delete = `DELETE FROM status WHERE mid='${movie}';`;
	db_status.run(sql_delete, (err,rows) => {
		if (err) console.log(err.message);
		// console.log(rows);
	});
	res.render('success',{
		'name': req.session.user.name
	});
});

// Login
app.post('/loginForm', (req,res) => {
	const name = req.body["name"];
	const password = req.body["password"];
	db_users.get(`SELECT * FROM users WHERE name='${name}'`,(err,row) => {
		if (row != undefined) {
			if (password == row.password) {
				req.session.user = row;
				req.session.authenticated = true;
				res.redirect('/allMovies');
			} else {
				res.render('error');
			}
		} else {
			res.render('error');
		} if (err) {
			console.error(error.message);
		}
	});
});

//Film ausleihen
app.post('/rentMovie', (req,res) => {
	console.log("/rentMovie:");
	const page = req.body["page"];
  const name = req.session.user.name;
	const sql_status = `INSERT INTO status (mid, uid, filmTitle) VALUES ('${page}','${name}','${page}')`;
	db_status.run(sql_status,(err, rows) => {
		if (rows) {
			console.log(page);
			console.log(name);
		}
	});
	res.redirect('/danke');
});

// Alle Filme anzeigen
app.get(['/allMovies'], (req,res) => {
    const sql = 'SELECT * FROM movies;';
    db_movies.all(sql, function(err, rows) {
		if (err) {
			console.log(err.message);
		} else {
			res.render('allMovies', {
        'rows': rows || [],
				'name': req.session.user.name
      }); // Falls "rows" leer ist ist es ein Nullpointer, daher übergeben wir eine leere liste
		}
	});
});

app.use((req, res, next) => {
  res.status(404).render('error');
});


// ================================================================ //


// ============== SQL =============== //
// PRAGMA table_info(table_name); -> zeigt alle Spaltennamen einer Tabelle
// ALTER TABLE table RENAME COLUMN oldname TO newname. -> Soll eigentlich funktionieren...
