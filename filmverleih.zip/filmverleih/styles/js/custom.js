//const rentButton = document.getElementById("rentButton");
